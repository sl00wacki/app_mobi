package com.example.aplikacjadownload.api;

import com.example.aplikacjadownload.model.NewsItem;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiService {
    @GET("5TP")
    Call<List<NewsItem>> getNews();
}
