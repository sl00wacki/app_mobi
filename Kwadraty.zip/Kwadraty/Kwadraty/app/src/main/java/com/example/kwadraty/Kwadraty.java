package com.example.kwadraty;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
public class Kwadraty extends View {

    public Kwadraty(Context context) {
        super(context);
    }
    public Kwadraty(Context context, AttributeSet attrs){
        super(context, attrs);
    }
    public Kwadraty(Context context, AttributeSet attrs, int defStyleAttr){
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int wid = getWidth(), hei = getHeight();
        int r = 200;

        Paint p = new Paint();
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.BLUE);
        canvas.drawRect(wid/2-r, hei/2-r, wid/2+r, hei/2+r, p);

        p.setColor(Color.RED);
        canvas.drawCircle(wid/2,hei/2, r, p);

        super.onDraw(canvas);
    }
}
